<?php
include('db.php');
if(isset($_POST['id'])){
    $id = $_GET['id'];
    echo $id;
    $result = mysqli_query("SELECT * from users"); 
   
}


?>